#include <RcppArmadillo.h>

typedef arma::mat mat;
typedef arma::vec vec;
typedef arma::vec uvec;
